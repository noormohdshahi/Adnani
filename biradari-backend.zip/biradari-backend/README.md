# Biradari Backend — Real-Time Messaging + Social API

> Node.js + Express + Socket.IO + MongoDB  
> WhatsApp-style messaging + Facebook-style feed

---

## 📁 Project Structure

```
biradari-backend/
├── server.js                   ← Entry point
├── .env.example                ← Environment config template
├── package.json
│
├── config/
│   └── db.js                   ← MongoDB connection
│
├── middleware/
│   ├── auth.js                 ← JWT protect, adminOnly, approvedOnly
│   ├── errorHandler.js         ← Global error handler
│   └── upload.js               ← Multer file uploads
│
├── models/
│   ├── User.js                 ← Users schema + indexes
│   ├── Chat.js                 ← Chat rooms schema
│   ├── Message.js              ← Messages schema
│   └── Post.js                 ← Posts + comments schema
│
├── controllers/
│   ├── authController.js       ← OTP login, profile setup
│   ├── userController.js       ← Users, contacts, status
│   ├── messageController.js    ← Send, receive, delete, edit
│   └── postController.js       ← Feed, like, comment
│
├── routes/
│   ├── auth.js
│   ├── users.js
│   ├── messages.js
│   └── posts.js
│
├── socket/
│   └── socketHandler.js        ← Complete Socket.IO engine
│
├── utils/
│   └── helpers.js
│
├── firebase/
│   └── firebaseSetup.js        ← Firebase alternative (Firestore + FCM)
│
└── frontend-examples/
    ├── api-examples.js         ← REST API calls
    └── socket-examples.js      ← Socket.IO client + React hooks
```

---

## ⚡ Quick Start

### 1. Install dependencies
```bash
cd biradari-backend
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
```

### 3. Start MongoDB
```bash
# Local:
mongod

# Or use MongoDB Atlas free cluster:
# mongodb+srv://user:pass@cluster.mongodb.net/biradari
```

### 4. Run server
```bash
npm run dev        # development (nodemon)
npm start          # production
```

Server runs at: `http://localhost:5000`

---

## 🔌 API Reference

### AUTH
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/send-otp` | Request OTP `{ phone }` |
| POST | `/api/auth/verify-otp` | Verify OTP → JWT token `{ phone, otp }` |
| PUT | `/api/auth/setup-profile` | First-time profile `{ name, username, city }` |
| GET | `/api/auth/me` | Get current user |

### USERS
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | List/search users `?search=name&page=1` |
| GET | `/api/users/:id` | Get user profile |
| PUT | `/api/users/profile` | Update profile + photo |
| GET | `/api/users/contacts` | My contacts list |
| POST | `/api/users/contacts/:id` | Add contact |
| DELETE | `/api/users/contacts/:id` | Remove contact |
| GET | `/api/users/status` | Online status `?ids=id1,id2` |
| GET | `/api/users/pending` | [Admin] Pending approvals |
| PUT | `/api/users/:id/approve` | [Admin] Approve/reject |

### MESSAGES
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/messages/chats` | All conversations |
| GET | `/api/messages/:userId` | Chat history `?page=1` |
| POST | `/api/messages/send` | Send message `{ receiverId, text }` |
| PUT | `/api/messages/:id` | Edit message `{ text }` |
| DELETE | `/api/messages/:id` | Delete message |

### POSTS
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/posts` | Feed `?page=1` |
| POST | `/api/posts` | Create post `{ content, postImage[] }` |
| POST | `/api/posts/:id/like` | Toggle like |
| POST | `/api/posts/:id/comment` | Add comment `{ text }` |
| DELETE | `/api/posts/:id` | Delete post |

---

## 🔌 Socket.IO Events

### Client → Server
| Event | Payload | Description |
|-------|---------|-------------|
| `sendMessage` | `{ receiverId, text, chatId, type }` | Send real-time message |
| `typing` | `{ receiverId, chatId }` | Start typing |
| `stopTyping` | `{ receiverId, chatId }` | Stop typing |
| `messageSeen` | `{ messageIds, chatId, senderId }` | Mark seen |
| `joinChat` | `{ chatId }` | Join chat room |
| `subscribeToFeed` | — | Subscribe to post updates |

### Server → Client
| Event | Payload | Description |
|-------|---------|-------------|
| `newMessage` | `{ chatId, message }` | New message received |
| `messageSent` | `{ chatId, status }` | Message confirmed |
| `messagesDelivered` | `{ chatId, messageIds }` | Delivery confirmation |
| `messagesSeen` | `{ chatId, messageIds, seenBy }` | Read receipts |
| `userTyping` | `{ senderId, chatId, typing }` | Typing indicator |
| `messageDeleted` | `{ messageId, chatId }` | Message deleted |
| `messageEdited` | `{ message }` | Message edited |
| `userOnline` | `{ userId }` | User came online |
| `userOffline` | `{ userId, lastSeen }` | User went offline |
| `onlineUsers` | `{ users: [userId] }` | Initial online list |
| `newPost` | `{ post }` | New post in feed |
| `postLiked` | `{ postId, likeCount }` | Post liked/unliked |
| `newComment` | `{ postId, comment }` | New comment |
| `postDeleted` | `{ postId }` | Post removed |
| `notification` | `{ type, from, data }` | General notification |
| `accountApproved` | `{ status }` | Admin approved account |

---

## 🔒 Authentication Flow

```
Mobile App
    │
    ├── POST /api/auth/send-otp  { phone: "9415061063" }
    │        ↓
    │   Server generates 6-digit OTP
    │   (logs to console in dev, SMS in production)
    │
    ├── POST /api/auth/verify-otp  { phone, otp }
    │        ↓
    │   Returns: { token, user, needsProfileSetup }
    │
    ├── [if needsProfileSetup] PUT /api/auth/setup-profile
    │        ↓
    │   Returns: updated user
    │
    └── All subsequent requests:
         Header: Authorization: Bearer <token>
```

---

## 🚀 Connecting to Your Adnani HTML App

In your `biradari-v6.html`, replace the localStorage-based backend with REST + Socket calls:

```javascript
// 1. On login success — store token
localStorage.setItem('token', data.token);

// 2. Connect socket
const socket = io('http://YOUR_SERVER:5000', {
  auth: { token: localStorage.getItem('token') }
});

// 3. On new message
socket.on('newMessage', ({ message }) => {
  // Add to chat UI
});

// 4. Send message
socket.emit('sendMessage', {
  receiverId: selectedUser._id,
  text: messageText,
  chatId: currentChatId
});

// 5. Load posts on home tab
fetch('http://YOUR_SERVER:5000/api/posts', {
  headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
}).then(r => r.json()).then(({ posts }) => {
  // Render posts
});
```

---

## 🌐 Production Deployment

### Option A — VPS (DigitalOcean / Linode / Hostinger)
```bash
# Install Node + PM2
npm install -g pm2

# Start with PM2 (auto-restart, clustering)
pm2 start server.js --name biradari -i max
pm2 save
pm2 startup

# Nginx reverse proxy config:
# location /api { proxy_pass http://localhost:5000; }
# location /socket.io { proxy_pass http://localhost:5000; }
```

### Option B — Railway / Render (free tier)
```bash
# Push to GitHub, connect to Railway/Render
# Set environment variables in dashboard
# They auto-deploy on push
```

### Option C — Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
EXPOSE 5000
CMD ["node", "server.js"]
```

---

## 📈 Scaling for Thousands of Users

### 1. MongoDB Atlas (managed)
- Use M10+ cluster for production
- Enable auto-scaling
- All indexes are already defined in models

### 2. Socket.IO with Redis Adapter (multiple servers)
```bash
npm install @socket.io/redis-adapter ioredis
```
```javascript
// In server.js
const { createAdapter } = require('@socket.io/redis-adapter');
const { createClient } = require('ioredis');

const pubClient = createClient({ url: process.env.REDIS_URL });
const subClient = pubClient.duplicate();
io.adapter(createAdapter(pubClient, subClient));
```

### 3. PM2 Cluster mode
```bash
pm2 start server.js -i max    # uses all CPU cores
```

### 4. Indexes already optimised for:
- `chatId + createdAt` — fast message pagination
- `phone + username` — fast user lookup
- `participants` — fast chat lookup
- `createdAt desc` — fast feed loading

---

## 🔥 Firebase Alternative

Use `firebase/firebaseSetup.js` instead of MongoDB controllers.

**When to use Firebase:**
- No server management required
- Free tier for small communities (< 50k reads/day)
- Built-in auth, storage, push notifications

**When to use Node.js + MongoDB:**
- Full control over data and logic
- Custom OTP flow
- Complex admin features
- Production scale (millions of messages)

---

## 📱 Mobile App Integration

### React Native
- Use `api-examples.js` for REST calls
- Use `socket-examples.js` hooks in components

### Flutter
```yaml
# pubspec.yaml
dependencies:
  socket_io_client: ^2.0.3
  http: ^1.1.0
```
```dart
import 'package:socket_io_client/socket_io_client.dart' as IO;

final socket = IO.io('http://YOUR_SERVER:5000', {
  'auth': {'token': token},
  'transports': ['websocket'],
});

socket.on('newMessage', (data) {
  // Handle new message
});
```

---

## ✅ Checklist Before Going Live

- [ ] Set strong `JWT_SECRET` in `.env`
- [ ] Set `NODE_ENV=production`
- [ ] Connect MongoDB Atlas (not localhost)
- [ ] Set up real SMS gateway (MSG91 / Twilio) for OTP
- [ ] Enable HTTPS (SSL certificate via Let's Encrypt)
- [ ] Set proper `CLIENT_URL` for CORS
- [ ] Enable MongoDB Atlas IP whitelist
- [ ] Set up PM2 for process management
- [ ] Configure Nginx as reverse proxy
- [ ] Set up daily database backups
