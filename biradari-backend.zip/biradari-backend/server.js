// ═══════════════════════════════════════════════════════
//  server.js  —  Biradari Backend  (Express + Socket.IO)
// ═══════════════════════════════════════════════════════
require('dotenv').config();
const express      = require('express');
const http         = require('http');
const { Server }   = require('socket.io');
const cors         = require('cors');
const path         = require('path');
const rateLimit    = require('express-rate-limit');

const connectDB    = require('./config/db');
const socketHandler = require('./socket/socketHandler');
const errorHandler = require('./middleware/errorHandler');

// ── Routes ────────────────────────────────────────────
const authRoutes    = require('./routes/auth');
const userRoutes    = require('./routes/users');
const chatRoutes    = require('./routes/chats');
const messageRoutes = require('./routes/messages');
const postRoutes    = require('./routes/posts');

// ── Connect DB ────────────────────────────────────────
connectDB();

const app    = express();
const server = http.createServer(app);

// ── Socket.IO ─────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || '*',
    methods: ['GET', 'POST'],
    credentials: true
  },
  pingTimeout: 60000
});

// Attach io to app so controllers can use it
app.set('io', io);

// ── Rate Limiting ─────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  message: { success: false, message: 'Too many requests, try again later.' }
});

// ── Middleware ────────────────────────────────────────
app.use(cors({ origin: process.env.CLIENT_URL || '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/', limiter);

// ── API Routes ────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/users',    userRoutes);
app.use('/api/chats',    chatRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/posts',    postRoutes);

// ── Health Check ──────────────────────────────────────
app.get('/health', (req, res) =>
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
);

// ── Socket.IO Handler ─────────────────────────────────
socketHandler(io);

// ── Error Handler (must be last) ──────────────────────
app.use(errorHandler);

// ── Start Server ──────────────────────────────────────
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`
  ┌─────────────────────────────────────┐
  │   Biradari Backend Running          │
  │   http://localhost:${PORT}               │
  │   ENV: ${process.env.NODE_ENV || 'development'}              │
  └─────────────────────────────────────┘
  `);
});

module.exports = { app, server, io };
