// socket/socketHandler.js
// ═══════════════════════════════════════════════════════
//  Complete Socket.IO real-time engine
//  Events: message, typing, online/offline, posts, notifications
// ═══════════════════════════════════════════════════════
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const Message = require('../models/Message');
const Chat    = require('../models/Chat');

// ── In-memory online users map  {userId → socketId} ──
const onlineUsers = new Map();

module.exports = (io) => {

  // ── Auth middleware for socket connections ───────────
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token ||
                    socket.handshake.headers?.authorization?.split(' ')[1];

      if (!token) return next(new Error('Authentication required'));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user    = await User.findById(decoded.id).select('_id name status role');

      if (!user)                  return next(new Error('User not found'));
      if (user.status === 'blocked') return next(new Error('Account blocked'));

      socket.userId = user._id.toString();
      socket.user   = user;
      next();

    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  // ── On connection ────────────────────────────────────
  io.on('connection', async (socket) => {
    const userId = socket.userId;
    console.log(`🟢 Connected: ${socket.user.name} [${socket.id}]`);

    // ── Join personal room ─────────────────────────────
    socket.join(`user_${userId}`);
    onlineUsers.set(userId, socket.id);

    // ── Mark user online in DB ─────────────────────────
    await User.findByIdAndUpdate(userId, {
      online:   true,
      socketId: socket.id
    });

    // ── Broadcast online status to everyone ───────────
    socket.broadcast.emit('userOnline', { userId });

    // ── Send current online users list to this socket ─
    socket.emit('onlineUsers', { users: Array.from(onlineUsers.keys()) });

    // ═══════════════════════════════════════════════════
    //  MESSAGING EVENTS
    // ═══════════════════════════════════════════════════

    // ── Send message (real-time only — also saved via REST) ──
    socket.on('sendMessage', async (data) => {
      try {
        const { receiverId, text, type = 'text', chatId, replyTo } = data;

        if (!receiverId || (!text && type === 'text')) return;

        // Emit to receiver's room
        io.to(`user_${receiverId}`).emit('newMessage', {
          chatId,
          message: {
            _id:        `temp_${Date.now()}`,
            senderId:   { _id: userId, name: socket.user.name },
            receiverId,
            text,
            type,
            status:     'sent',
            replyTo:    replyTo || null,
            createdAt:  new Date()
          }
        });

        // Confirm to sender
        socket.emit('messageSent', { chatId, status: 'sent' });

        // Mark delivered if receiver is online
        if (onlineUsers.has(receiverId)) {
          io.to(`user_${receiverId}`).emit('messageDelivered', { chatId });
        }

      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    // ── Typing indicator ──────────────────────────────
    socket.on('typing', ({ receiverId, chatId }) => {
      io.to(`user_${receiverId}`).emit('userTyping', {
        senderId: userId,
        chatId,
        typing: true
      });
    });

    socket.on('stopTyping', ({ receiverId, chatId }) => {
      io.to(`user_${receiverId}`).emit('userTyping', {
        senderId: userId,
        chatId,
        typing: false
      });
    });

    // ── Message seen ──────────────────────────────────
    socket.on('messageSeen', async ({ messageIds, chatId, senderId }) => {
      try {
        if (!Array.isArray(messageIds) || !messageIds.length) return;

        await Message.updateMany(
          { _id: { $in: messageIds }, status: { $ne: 'seen' } },
          { status: 'seen', seenAt: new Date() }
        );

        await Chat.findByIdAndUpdate(chatId, {
          $set: { [`unreadCount.${userId}`]: 0 }
        });

        // Notify original sender
        io.to(`user_${senderId}`).emit('messagesSeen', {
          chatId,
          messageIds,
          seenBy: userId,
          seenAt: new Date()
        });

      } catch (err) {
        console.error('messageSeen error:', err.message);
      }
    });

    // ── Message delivered ack ─────────────────────────
    socket.on('messageDelivered', async ({ messageIds, chatId, senderId }) => {
      try {
        if (!Array.isArray(messageIds) || !messageIds.length) return;

        await Message.updateMany(
          { _id: { $in: messageIds }, status: 'sent' },
          { status: 'delivered', deliveredAt: new Date() }
        );

        io.to(`user_${senderId}`).emit('messagesDelivered', { chatId, messageIds });

      } catch (err) {
        console.error('messageDelivered error:', err.message);
      }
    });

    // ── Join chat room (for group chat later) ─────────
    socket.on('joinChat', ({ chatId }) => {
      socket.join(`chat_${chatId}`);
    });

    socket.on('leaveChat', ({ chatId }) => {
      socket.leave(`chat_${chatId}`);
    });

    // ═══════════════════════════════════════════════════
    //  POST / SOCIAL EVENTS
    // ═══════════════════════════════════════════════════

    // ── New post broadcast (triggered from REST controller) ──
    // Posts are broadcast via io.emit('newPost') in postController
    // but clients can also subscribe here

    socket.on('subscribeToFeed', () => {
      socket.join('feed');
    });

    socket.on('unsubscribeFromFeed', () => {
      socket.leave('feed');
    });

    // ── Real-time reaction (like without REST call) ───
    socket.on('reactPost', ({ postId, liked }) => {
      socket.broadcast.emit('postReaction', {
        postId,
        userId,
        liked
      });
    });

    // ═══════════════════════════════════════════════════
    //  NOTIFICATIONS
    // ═══════════════════════════════════════════════════

    socket.on('sendNotification', ({ toUserId, type, data }) => {
      io.to(`user_${toUserId}`).emit('notification', {
        type,
        from:      { _id: userId, name: socket.user.name },
        data,
        timestamp: new Date()
      });
    });

    // ═══════════════════════════════════════════════════
    //  DISCONNECT
    // ═══════════════════════════════════════════════════

    socket.on('disconnect', async (reason) => {
      console.log(`🔴 Disconnected: ${socket.user.name} — ${reason}`);

      onlineUsers.delete(userId);

      const lastSeen = new Date();
      await User.findByIdAndUpdate(userId, {
        online:   false,
        lastSeen,
        socketId: ''
      });

      socket.broadcast.emit('userOffline', { userId, lastSeen });
    });

    // ── Handle socket errors ──────────────────────────
    socket.on('error', (err) => {
      console.error(`Socket error [${socket.user.name}]:`, err.message);
    });

  }); // end io.on('connection')

  // ── Export helper to get online users ────────────────
  io.getOnlineUsers = () => Array.from(onlineUsers.keys());
  io.isUserOnline   = (userId) => onlineUsers.has(userId);

};
