// routes/chats.js
// Chat list is served via /api/messages/chats
// This file exists for future group chat expansion

const express = require('express');
const router  = express.Router();
const { protect, approvedOnly } = require('../middleware/auth');
const { getChats } = require('../controllers/messageController');

// GET /api/chats  — all conversations for current user
router.get('/', protect, approvedOnly, getChats);

module.exports = router;
