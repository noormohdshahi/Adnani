// routes/users.js
const express = require('express');
const router  = express.Router();
const { protect, adminOnly, approvedOnly } = require('../middleware/auth');
const upload  = require('../middleware/upload');
const {
  getUsers, getUser, getContacts, addContact, removeContact,
  updateProfile, getUserStatus, getPendingUsers, approveUser
} = require('../controllers/userController');

router.get('/',               protect, approvedOnly, getUsers);
router.get('/status',         protect, getUserStatus);
router.get('/contacts',       protect, approvedOnly, getContacts);
router.get('/pending',        protect, adminOnly,    getPendingUsers);
router.put('/profile',        protect, upload.single('profilePic'), updateProfile);
router.get('/:id',            protect, getUser);
router.post('/contacts/:id',  protect, addContact);
router.delete('/contacts/:id',protect, removeContact);
router.put('/:id/approve',    protect, adminOnly, approveUser);

module.exports = router;
