// routes/messages.js
const express = require('express');
const router  = express.Router();
const { protect, approvedOnly } = require('../middleware/auth');
const upload  = require('../middleware/upload');
const {
  sendMessage, getMessages, getChats, deleteMessage, editMessage
} = require('../controllers/messageController');

router.get('/chats',                protect, approvedOnly, getChats);
router.post('/send',                protect, approvedOnly, upload.single('media'), sendMessage);
router.get('/:userId',              protect, approvedOnly, getMessages);
router.delete('/:messageId',        protect, deleteMessage);
router.put('/:messageId',           protect, editMessage);

module.exports = router;
