// routes/posts.js
const express = require('express');
const router  = express.Router();
const { protect, approvedOnly } = require('../middleware/auth');
const upload  = require('../middleware/upload');
const {
  createPost, getPosts, likePost, addComment, deleteComment, deletePost
} = require('../controllers/postController');

router.get('/',                              protect, approvedOnly, getPosts);
router.post('/',                             protect, approvedOnly, upload.array('postImage', 4), createPost);
router.post('/:id/like',                     protect, approvedOnly, likePost);
router.post('/:id/comment',                  protect, approvedOnly, addComment);
router.delete('/:id/comment/:commentId',     protect, deleteComment);
router.delete('/:id',                        protect, deletePost);

module.exports = router;
