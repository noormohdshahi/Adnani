// frontend-examples/api-examples.js
// ═══════════════════════════════════════════════════════
//  Frontend Integration — API + Socket.IO examples
//  Works with: React Native, Flutter (Dart), plain JS
// ═══════════════════════════════════════════════════════

const BASE_URL = 'http://YOUR_SERVER_IP:5000/api';   // change this

// ── Token storage (React Native AsyncStorage) ─────────
// import AsyncStorage from '@react-native-async-storage/async-storage';
// const getToken = () => AsyncStorage.getItem('token');
// For web: const getToken = () => localStorage.getItem('token');
const getToken = () => localStorage.getItem('token');

// ── Base fetch wrapper ────────────────────────────────
const api = async (path, options = {}) => {
  const token = getToken();
  const res   = await fetch(`${BASE_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers
    },
    ...options
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.message);
  return data;
};

// ════════════════════════════════════════════════════════
//  1. AUTH FLOW
// ════════════════════════════════════════════════════════

// Step 1: Request OTP
const requestOTP = async (phone) => {
  const data = await api('/auth/send-otp', {
    method: 'POST',
    body:   JSON.stringify({ phone })
  });
  console.log('OTP sent:', data.message);
  return data;
};

// Step 2: Verify OTP → get JWT token
const verifyOTP = async (phone, otp) => {
  const data = await api('/auth/verify-otp', {
    method: 'POST',
    body:   JSON.stringify({ phone, otp })
  });

  // Save token
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));

  if (data.needsProfileSetup) {
    // Redirect to profile setup screen
    console.log('→ Show profile setup');
  } else {
    // Redirect to home
    console.log('→ Go to home, user:', data.user.name);
  }
  return data;
};

// Step 3 (new users): Setup profile
const setupProfile = async ({ name, username, city }) => {
  const data = await api('/auth/setup-profile', {
    method: 'PUT',
    body:   JSON.stringify({ name, username, city })
  });
  return data.user;
};

// Get current user
const getMe = async () => {
  const data = await api('/auth/me');
  return data.user;
};

// ════════════════════════════════════════════════════════
//  2. USERS
// ════════════════════════════════════════════════════════

// Search users
const searchUsers = async (query, page = 1) => {
  const data = await api(`/users?search=${encodeURIComponent(query)}&page=${page}`);
  return data.users;
};

// Get all approved users
const getAllUsers = async (page = 1) => {
  const data = await api(`/users?page=${page}&limit=20`);
  return { users: data.users, total: data.total };
};

// Get single user
const getUserById = async (userId) => {
  const data = await api(`/users/${userId}`);
  return data.user;
};

// Get my contacts
const getContacts = async () => {
  const data = await api('/users/contacts');
  return data.contacts;
};

// Add contact
const addContact = async (userId) => {
  await api(`/users/contacts/${userId}`, { method: 'POST' });
};

// Get online status of multiple users
const getUsersStatus = async (userIds) => {
  const data = await api(`/users/status?ids=${userIds.join(',')}`);
  return data.status;   // { userId: { online, lastSeen } }
};

// Update profile (with photo)
const updateProfile = async ({ name, username, bio, city, photoFile }) => {
  const form = new FormData();
  if (name)      form.append('name', name);
  if (username)  form.append('username', username);
  if (bio)       form.append('bio', bio);
  if (city)      form.append('city', city);
  if (photoFile) form.append('profilePic', photoFile);

  const token = getToken();
  const res   = await fetch(`${BASE_URL}/users/profile`, {
    method:  'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body:    form
  });
  return res.json();
};

// ════════════════════════════════════════════════════════
//  3. MESSAGES
// ════════════════════════════════════════════════════════

// Get all chat conversations
const getChats = async () => {
  const data = await api('/messages/chats');
  return data.chats;
};

// Get messages with a specific user
const getMessages = async (userId, page = 1) => {
  const data = await api(`/messages/${userId}?page=${page}&limit=30`);
  return { chatId: data.chatId, messages: data.messages };
};

// Send text message
const sendMessage = async ({ receiverId, text, replyToId }) => {
  const data = await api('/messages/send', {
    method: 'POST',
    body:   JSON.stringify({ receiverId, text, type: 'text', replyTo: replyToId })
  });
  return data.message;
};

// Send media message (image/audio/document)
const sendMediaMessage = async ({ receiverId, file, type }) => {
  const form  = new FormData();
  const token = getToken();

  form.append('receiverId', receiverId);
  form.append('type', type);
  form.append('media', file);

  const res = await fetch(`${BASE_URL}/messages/send`, {
    method:  'POST',
    headers: { Authorization: `Bearer ${token}` },
    body:    form
  });
  return res.json();
};

// Delete message
const deleteMessage = async (messageId) => {
  await api(`/messages/${messageId}`, { method: 'DELETE' });
};

// Edit message
const editMessage = async (messageId, text) => {
  const data = await api(`/messages/${messageId}`, {
    method: 'PUT',
    body:   JSON.stringify({ text })
  });
  return data.message;
};

// ════════════════════════════════════════════════════════
//  4. POSTS
// ════════════════════════════════════════════════════════

// Get posts feed
const getPosts = async (page = 1) => {
  const data = await api(`/posts?page=${page}&limit=15`);
  return { posts: data.posts, total: data.total };
};

// Create text post
const createTextPost = async (content) => {
  const data = await api('/posts', {
    method: 'POST',
    body:   JSON.stringify({ content, type: 'text' })
  });
  return data.post;
};

// Create post with image
const createImagePost = async ({ content, imageFiles }) => {
  const form  = new FormData();
  const token = getToken();

  form.append('content', content);
  imageFiles.forEach(f => form.append('postImage', f));

  const res = await fetch(`${BASE_URL}/posts`, {
    method:  'POST',
    headers: { Authorization: `Bearer ${token}` },
    body:    form
  });
  return res.json();
};

// Like / unlike post
const likePost = async (postId) => {
  const data = await api(`/posts/${postId}/like`, { method: 'POST' });
  return { liked: data.liked, likeCount: data.likeCount };
};

// Add comment
const addComment = async (postId, text) => {
  const data = await api(`/posts/${postId}/comment`, {
    method: 'POST',
    body:   JSON.stringify({ text })
  });
  return data.comment;
};

// Delete post
const deletePost = async (postId) => {
  await api(`/posts/${postId}`, { method: 'DELETE' });
};

// ════════════════════════════════════════════════════════
//  COMPLETE USAGE EXAMPLE
// ════════════════════════════════════════════════════════

async function fullExample() {
  // 1. Login
  await requestOTP('9415061063');
  const { token, user } = await verifyOTP('9415061063', '123456');
  console.log('Logged in as:', user.name);

  // 2. Get feed
  const { posts } = await getPosts();
  console.log('Posts:', posts.length);

  // 3. Like first post
  if (posts.length) {
    const { liked, likeCount } = await likePost(posts[0]._id);
    console.log(`Post ${liked ? 'liked' : 'unliked'}, total likes: ${likeCount}`);
  }

  // 4. Get chats
  const chats = await getChats();
  console.log('Conversations:', chats.length);

  // 5. Send message
  const msg = await sendMessage({
    receiverId: 'some_user_id',
    text:       'Assalamu Alaikum!'
  });
  console.log('Message sent:', msg._id);
}

module.exports = {
  requestOTP, verifyOTP, setupProfile, getMe,
  searchUsers, getAllUsers, getUserById, getContacts,
  addContact, getUsersStatus, updateProfile,
  getChats, getMessages, sendMessage, sendMediaMessage,
  deleteMessage, editMessage,
  getPosts, createTextPost, createImagePost,
  likePost, addComment, deletePost
};
