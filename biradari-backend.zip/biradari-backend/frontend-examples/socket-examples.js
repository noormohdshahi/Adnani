// frontend-examples/socket-examples.js
// ═══════════════════════════════════════════════════════
//  Socket.IO Client — Complete Integration
//  Covers: connect, messaging, typing, online, posts
// ═══════════════════════════════════════════════════════

// npm install socket.io-client   (for React Native / Web)
// For Flutter: use socket_io_client package

import { io } from 'socket.io-client';

const SERVER_URL = 'http://YOUR_SERVER_IP:5000';

// ════════════════════════════════════════════════════════
//  SOCKET MANAGER CLASS — use as singleton
// ════════════════════════════════════════════════════════

class SocketManager {
  constructor() {
    this.socket        = null;
    this.onlineUsers   = new Set();
    this.typingTimers  = {};
    this.listeners     = {};
    this.reconnectTries = 0;
  }

  // ── Connect with JWT token ──────────────────────────
  connect(token) {
    if (this.socket?.connected) return this.socket;

    this.socket = io(SERVER_URL, {
      auth:             { token },
      transports:       ['websocket', 'polling'],
      reconnection:     true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
      timeout:          20000
    });

    this._bindCoreEvents();
    return this.socket;
  }

  // ── Disconnect ──────────────────────────────────────
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  // ── Core event bindings ─────────────────────────────
  _bindCoreEvents() {
    const s = this.socket;

    s.on('connect', () => {
      console.log('✅ Socket connected:', s.id);
      this.reconnectTries = 0;
      this._emit('connectionChange', { connected: true });
    });

    s.on('disconnect', (reason) => {
      console.log('🔴 Socket disconnected:', reason);
      this._emit('connectionChange', { connected: false, reason });
    });

    s.on('connect_error', (err) => {
      console.error('❌ Socket error:', err.message);
      this.reconnectTries++;
    });

    // Online/offline
    s.on('userOnline',  ({ userId }) => {
      this.onlineUsers.add(userId);
      this._emit('onlineChange', { userId, online: true });
    });

    s.on('userOffline', ({ userId, lastSeen }) => {
      this.onlineUsers.delete(userId);
      this._emit('onlineChange', { userId, online: false, lastSeen });
    });

    s.on('onlineUsers', ({ users }) => {
      this.onlineUsers = new Set(users);
      this._emit('onlineUsersList', { users });
    });
  }

  // ── Subscribe to an event ───────────────────────────
  on(event, callback) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
    if (this.socket) this.socket.on(event, callback);
    return () => this.off(event, callback);   // returns unsubscribe fn
  }

  off(event, callback) {
    if (this.socket) this.socket.off(event, callback);
    if (this.listeners[event]) {
      this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
    }
  }

  _emit(event, data) {
    (this.listeners[event] || []).forEach(cb => cb(data));
  }

  isOnline(userId) {
    return this.onlineUsers.has(userId);
  }

  // ════════════════════════════════════════════════════
  //  MESSAGING
  // ════════════════════════════════════════════════════

  // Send message via socket (instant, also call REST /send)
  sendMessage({ receiverId, text, chatId, type = 'text', replyTo }) {
    this.socket?.emit('sendMessage', { receiverId, text, chatId, type, replyTo });
  }

  // Listen for incoming messages
  onNewMessage(callback) {
    return this.on('newMessage', callback);
  }

  // Message status updates
  onMessageDelivered(callback) {
    return this.on('messagesDelivered', callback);
  }

  onMessageSeen(callback) {
    return this.on('messagesSeen', callback);
  }

  // Mark messages as seen
  markSeen({ messageIds, chatId, senderId }) {
    this.socket?.emit('messageSeen', { messageIds, chatId, senderId });
  }

  // Typing indicator — auto-debounced
  sendTyping({ receiverId, chatId }) {
    this.socket?.emit('typing', { receiverId, chatId });

    // Auto stop typing after 2s
    clearTimeout(this.typingTimers[receiverId]);
    this.typingTimers[receiverId] = setTimeout(() => {
      this.socket?.emit('stopTyping', { receiverId, chatId });
    }, 2000);
  }

  onTyping(callback) {
    return this.on('userTyping', callback);
  }

  // Deleted message
  onMessageDeleted(callback) {
    return this.on('messageDeleted', callback);
  }

  // Edited message
  onMessageEdited(callback) {
    return this.on('messageEdited', callback);
  }

  // ════════════════════════════════════════════════════
  //  POSTS / FEED
  // ════════════════════════════════════════════════════

  subscribeToFeed() {
    this.socket?.emit('subscribeToFeed');
  }

  onNewPost(callback) {
    return this.on('newPost', callback);
  }

  onPostLiked(callback) {
    return this.on('postLiked', callback);
  }

  onNewComment(callback) {
    return this.on('newComment', callback);
  }

  onPostDeleted(callback) {
    return this.on('postDeleted', callback);
  }

  // ════════════════════════════════════════════════════
  //  NOTIFICATIONS
  // ════════════════════════════════════════════════════

  onNotification(callback) {
    return this.on('notification', callback);
  }

  onAccountApproved(callback) {
    return this.on('accountApproved', callback);
  }
}

// Singleton export
export const socketManager = new SocketManager();

// ════════════════════════════════════════════════════════
//  REACT HOOKS
// ════════════════════════════════════════════════════════

import { useState, useEffect, useRef, useCallback } from 'react';

// ── useSocket — manage connection ────────────────────
export function useSocket(token) {
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!token) return;
    socketManager.connect(token);

    const unsub = socketManager.on('connectionChange', ({ connected }) => {
      setConnected(connected);
    });

    return () => {
      unsub();
      socketManager.disconnect();
    };
  }, [token]);

  return { connected, socket: socketManager };
}

// ── useMessages — real-time chat for one conversation ─
export function useMessages(chatId, otherUserId) {
  const [messages, setMessages]   = useState([]);
  const [typing,   setTyping]     = useState(false);
  const typingTimer               = useRef(null);

  useEffect(() => {
    if (!chatId) return;

    // New incoming message
    const unsubMsg = socketManager.onNewMessage((data) => {
      if (data.chatId !== chatId) return;
      setMessages(prev => [...prev, data.message]);

      // Auto-mark as seen
      socketManager.markSeen({
        messageIds: [data.message._id],
        chatId,
        senderId: otherUserId
      });
    });

    // Message deleted
    const unsubDel = socketManager.onMessageDeleted((data) => {
      if (data.chatId !== chatId) return;
      setMessages(prev =>
        prev.map(m => m._id === data.messageId
          ? { ...m, isDeleted: true, text: '' }
          : m
        )
      );
    });

    // Message edited
    const unsubEdit = socketManager.onMessageEdited((data) => {
      setMessages(prev =>
        prev.map(m => m._id === data.message._id ? data.message : m)
      );
    });

    // Typing
    const unsubTyping = socketManager.onTyping((data) => {
      if (data.senderId !== otherUserId) return;
      setTyping(data.typing);

      clearTimeout(typingTimer.current);
      if (data.typing) {
        typingTimer.current = setTimeout(() => setTyping(false), 3000);
      }
    });

    return () => { unsubMsg(); unsubDel(); unsubEdit(); unsubTyping(); };
  }, [chatId, otherUserId]);

  // Status updates (delivered/seen ticks)
  useEffect(() => {
    const unsubDel  = socketManager.onMessageDelivered((data) => {
      if (data.chatId !== chatId) return;
      setMessages(prev =>
        prev.map(m => data.messageIds?.includes(m._id)
          ? { ...m, status: 'delivered' } : m)
      );
    });

    const unsubSeen = socketManager.onMessageSeen((data) => {
      if (data.chatId !== chatId) return;
      setMessages(prev =>
        prev.map(m => data.messageIds?.includes(m._id)
          ? { ...m, status: 'seen' } : m)
      );
    });

    return () => { unsubDel(); unsubSeen(); };
  }, [chatId]);

  const sendTypingIndicator = useCallback(() => {
    socketManager.sendTyping({ receiverId: otherUserId, chatId });
  }, [chatId, otherUserId]);

  return { messages, setMessages, typing, sendTypingIndicator };
}

// ── useOnlineStatus — track a user's online state ────
export function useOnlineStatus(userId) {
  const [online,   setOnline]   = useState(socketManager.isOnline(userId));
  const [lastSeen, setLastSeen] = useState(null);

  useEffect(() => {
    if (!userId) return;
    setOnline(socketManager.isOnline(userId));

    const unsub = socketManager.on('onlineChange', (data) => {
      if (data.userId !== userId) return;
      setOnline(data.online);
      if (!data.online && data.lastSeen) setLastSeen(data.lastSeen);
    });

    return unsub;
  }, [userId]);

  return { online, lastSeen };
}

// ── useFeed — real-time posts feed ───────────────────
export function useFeed() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    socketManager.subscribeToFeed();

    const unsubNew = socketManager.onNewPost(({ post }) => {
      setPosts(prev => [post, ...prev]);
    });

    const unsubLike = socketManager.onPostLiked(({ postId, likeCount, userId, liked }) => {
      const me = JSON.parse(localStorage.getItem('user') || '{}')._id;
      setPosts(prev => prev.map(p =>
        p._id === postId
          ? { ...p, likeCount, hasLiked: userId === me ? liked : p.hasLiked }
          : p
      ));
    });

    const unsubComment = socketManager.onNewComment(({ postId, comment }) => {
      setPosts(prev => prev.map(p =>
        p._id === postId
          ? { ...p, comments: [...(p.comments || []), comment] }
          : p
      ));
    });

    const unsubDel = socketManager.onPostDeleted(({ postId }) => {
      setPosts(prev => prev.filter(p => p._id !== postId));
    });

    return () => { unsubNew(); unsubLike(); unsubComment(); unsubDel(); };
  }, []);

  return { posts, setPosts };
}

// ════════════════════════════════════════════════════════
//  REACT NATIVE — FULL CHAT SCREEN EXAMPLE
// ════════════════════════════════════════════════════════

/*
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { getMessages, sendMessage } from './api-examples';
import { useMessages, useOnlineStatus } from './socket-examples';

export default function ChatScreen({ route }) {
  const { chatId, otherUser } = route.params;
  const [input, setInput] = useState('');
  const [page,  setPage]  = useState(1);

  const { messages, setMessages, typing, sendTypingIndicator } = useMessages(chatId, otherUser._id);
  const { online, lastSeen } = useOnlineStatus(otherUser._id);

  // Load existing messages from REST
  useEffect(() => {
    getMessages(otherUser._id, page).then(({ messages: msgs }) => {
      setMessages(msgs);
    });
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;
    const text = input.trim();
    setInput('');

    // Optimistic update
    const tempMsg = {
      _id: `temp_${Date.now()}`,
      senderId: { _id: 'me' },
      text,
      status: 'sent',
      createdAt: new Date()
    };
    setMessages(prev => [...prev, tempMsg]);

    // Send via REST (persists to DB)
    const saved = await sendMessage({ receiverId: otherUser._id, text });

    // Replace temp with saved
    setMessages(prev => prev.map(m => m._id === tempMsg._id ? saved : m));
  };

  const statusIcon = (status) => {
    if (status === 'seen')      return '✓✓';  // blue ticks
    if (status === 'delivered') return '✓✓';  // grey ticks
    return '✓';                               // single tick
  };

  return (
    <View style={styles.container}>
      // Header
      <View style={styles.header}>
        <Text style={styles.name}>{otherUser.name}</Text>
        <Text style={styles.status}>
          {online ? '● Online' : lastSeen ? `Last seen ${lastSeen}` : '○ Offline'}
        </Text>
      </View>

      // Typing indicator
      {typing && (
        <Text style={styles.typing}>{otherUser.name} is typing...</Text>
      )}

      // Messages
      <FlatList
        data={messages}
        keyExtractor={m => m._id}
        renderItem={({ item: m }) => {
          const isMe = m.senderId?._id === 'me' || m.senderId === 'me';
          return (
            <View style={[styles.bubble, isMe ? styles.myBubble : styles.theirBubble]}>
              {m.isDeleted
                ? <Text style={styles.deleted}>🚫 Message deleted</Text>
                : <Text style={styles.msgText}>{m.text}</Text>
              }
              {isMe && <Text style={styles.status}>{statusIcon(m.status)}</Text>}
            </View>
          );
        }}
      />

      // Input
      <View style={styles.inputRow}>
        <TextInput
          value={input}
          onChangeText={(t) => { setInput(t); sendTypingIndicator(); }}
          placeholder="Type a message..."
          style={styles.input}
        />
        <TouchableOpacity onPress={handleSend} style={styles.sendBtn}>
          <Text>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1, backgroundColor: '#f5f5f5' },
  header:      { padding: 16, backgroundColor: '#1a5c38' },
  name:        { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  status:      { color: 'rgba(255,255,255,.7)', fontSize: 12 },
  typing:      { padding: 8, color: '#888', fontStyle: 'italic' },
  bubble:      { maxWidth: '75%', padding: 10, borderRadius: 12, margin: 4 },
  myBubble:    { alignSelf: 'flex-end', backgroundColor: '#dcf8c6' },
  theirBubble: { alignSelf: 'flex-start', backgroundColor: '#fff' },
  msgText:     { fontSize: 14 },
  deleted:     { fontSize: 13, color: '#999', fontStyle: 'italic' },
  inputRow:    { flexDirection: 'row', padding: 8, backgroundColor: '#fff' },
  input:       { flex: 1, borderWidth: 1, borderColor: '#ddd', borderRadius: 20, padding: 10 },
  sendBtn:     { marginLeft: 8, padding: 10, backgroundColor: '#1a5c38', borderRadius: 20 },
});
*/
