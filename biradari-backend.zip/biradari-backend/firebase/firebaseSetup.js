// firebase/firebaseSetup.js
// ═══════════════════════════════════════════════════════
//  FIREBASE ALTERNATIVE — Complete implementation
//  Drop-in replacement for MongoDB + Socket.IO stack
//  Uses: Firestore + Realtime DB + FCM + Auth
// ═══════════════════════════════════════════════════════

/*
  SETUP STEPS:
  1. npm install firebase-admin
  2. Go to Firebase Console → Project Settings → Service Accounts
  3. Generate new private key → download JSON
  4. Set FIREBASE_SERVICE_ACCOUNT_PATH in .env
  5. Replace MongoDB controllers with these Firebase equivalents
*/

const admin = require('firebase-admin');

// ── Initialize Firebase Admin ─────────────────────────
let db, rtdb, messaging;

const initFirebase = () => {
  if (admin.apps.length) return;   // already initialized

  const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH ||
                                  './serviceAccountKey.json');
  admin.initializeApp({
    credential:   admin.credential.cert(serviceAccount),
    databaseURL:  `https://${serviceAccount.project_id}-default-rtdb.firebaseio.com`
  });

  db        = admin.firestore();
  rtdb      = admin.database();
  messaging = admin.messaging();

  console.log('✅ Firebase Admin initialized');
};

// ═══════════════════════════════════════════════════════
//  FIRESTORE COLLECTIONS STRUCTURE
// ═══════════════════════════════════════════════════════
/*
  users/{userId}
    name, phone, username, profilePic, bio, city
    online, lastSeen, fcmToken, status, role

  chats/{chatId}
    participants: [userId1, userId2]
    lastMessage, lastMessageText, lastMessageTime
    unreadCount: { userId1: 0, userId2: 2 }

  chats/{chatId}/messages/{messageId}
    senderId, receiverId, text, type
    status: sent|delivered|seen
    timestamp, isDeleted, isEdited

  posts/{postId}
    userId, content, images[]
    likes: [userId], comments[]
    createdAt, isDeleted

  notifications/{userId}/items/{notifId}
    type, fromUserId, data, read, createdAt
*/

// ═══════════════════════════════════════════════════════
//  USER FUNCTIONS
// ═══════════════════════════════════════════════════════

const createOrUpdateUser = async (userId, data) => {
  await db.collection('users').doc(userId).set(data, { merge: true });
};

const getUser = async (userId) => {
  const doc = await db.collection('users').doc(userId).get();
  return doc.exists ? { id: doc.id, ...doc.data() } : null;
};

const searchUsers = async (query) => {
  // Firestore doesn't support full-text search natively
  // Use Algolia/Typesense for production search
  // Simple prefix search on name:
  const snap = await db.collection('users')
    .where('status', '==', 'approved')
    .where('name', '>=', query)
    .where('name', '<=', query + '\uf8ff')
    .limit(20)
    .get();

  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

const setOnlineStatus = async (userId, online) => {
  await db.collection('users').doc(userId).update({
    online,
    lastSeen: admin.firestore.FieldValue.serverTimestamp()
  });

  // Also update Realtime DB for presence (faster)
  await rtdb.ref(`presence/${userId}`).set({
    online,
    lastSeen: Date.now()
  });
};

// ── Realtime DB presence listener (client-side) ───────
// This goes in your Flutter/React Native app:
/*
  const presenceRef = firebase.database().ref(`presence/${userId}`);
  presenceRef.onDisconnect().update({ online: false, lastSeen: Date.now() });
  presenceRef.update({ online: true });
*/

// ═══════════════════════════════════════════════════════
//  CHAT & MESSAGING
// ═══════════════════════════════════════════════════════

const getChatId = (userId1, userId2) =>
  [userId1, userId2].sort().join('_');

const sendMessage = async ({ senderId, receiverId, text, type = 'text' }) => {
  const chatId   = getChatId(senderId, receiverId);
  const chatRef  = db.collection('chats').doc(chatId);
  const msgsRef  = chatRef.collection('messages');

  const batch = db.batch();

  // Create message
  const msgRef = msgsRef.doc();
  batch.set(msgRef, {
    senderId,
    receiverId,
    text,
    type,
    status:    'sent',
    isDeleted: false,
    isEdited:  false,
    timestamp: admin.firestore.FieldValue.serverTimestamp()
  });

  // Update chat metadata
  batch.set(chatRef, {
    participants:    [senderId, receiverId],
    lastMessageText: text || `[${type}]`,
    lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
    [`unreadCount.${receiverId}`]: admin.firestore.FieldValue.increment(1)
  }, { merge: true });

  await batch.commit();

  // Send FCM push notification
  await sendPushNotification(receiverId, {
    title: 'New Message',
    body:  text || 'Sent an attachment',
    data:  { type: 'message', chatId, senderId }
  });

  return msgRef.id;
};

const getMessages = async (userId1, userId2, limit = 30, startAfter = null) => {
  const chatId = getChatId(userId1, userId2);
  let query = db.collection('chats').doc(chatId)
    .collection('messages')
    .orderBy('timestamp', 'desc')
    .limit(limit);

  if (startAfter) query = query.startAfter(startAfter);

  const snap = await query.get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

const markMessagesSeen = async (chatId, userId, senderId) => {
  const msgsSnap = await db.collection('chats').doc(chatId)
    .collection('messages')
    .where('receiverId', '==', userId)
    .where('status', 'in', ['sent', 'delivered'])
    .get();

  const batch = db.batch();
  msgsSnap.docs.forEach(doc => {
    batch.update(doc.ref, { status: 'seen', seenAt: Date.now() });
  });

  batch.update(db.collection('chats').doc(chatId), {
    [`unreadCount.${userId}`]: 0
  });

  await batch.commit();
};

// ── Realtime listener for messages (client-side Flutter) ──
/*
  FirebaseFirestore.instance
    .collection('chats')
    .doc(chatId)
    .collection('messages')
    .orderBy('timestamp', descending: false)
    .snapshots()
    .listen((snapshot) {
      snapshot.docChanges.forEach((change) {
        if (change.type == DocumentChangeType.added) {
          // New message arrived
          final msg = change.doc.data();
          // Update UI
        }
      });
    });
*/

// ═══════════════════════════════════════════════════════
//  POSTS
// ═══════════════════════════════════════════════════════

const createPost = async ({ userId, content, images = [] }) => {
  const ref = await db.collection('posts').add({
    userId,
    content,
    images,
    likes:     [],
    comments:  [],
    isDeleted: false,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return ref.id;
};

const getPosts = async (limit = 15, startAfter = null) => {
  let query = db.collection('posts')
    .where('isDeleted', '==', false)
    .orderBy('createdAt', 'desc')
    .limit(limit);

  if (startAfter) query = query.startAfter(startAfter);

  const snap = await query.get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

const toggleLike = async (postId, userId) => {
  const ref  = db.collection('posts').doc(postId);
  const post = await ref.get();
  if (!post.exists) throw new Error('Post not found');

  const likes = post.data().likes || [];
  const liked = likes.includes(userId);

  await ref.update({
    likes: liked
      ? admin.firestore.FieldValue.arrayRemove(userId)
      : admin.firestore.FieldValue.arrayUnion(userId)
  });

  return !liked;
};

const addComment = async (postId, { userId, text }) => {
  const comment = { id: Date.now().toString(), userId, text, createdAt: Date.now() };
  await db.collection('posts').doc(postId).update({
    comments: admin.firestore.FieldValue.arrayUnion(comment)
  });
  return comment;
};

// ═══════════════════════════════════════════════════════
//  FCM PUSH NOTIFICATIONS
// ═══════════════════════════════════════════════════════

const sendPushNotification = async (userId, { title, body, data = {} }) => {
  try {
    const user = await getUser(userId);
    if (!user?.fcmToken) return;

    await messaging.send({
      token: user.fcmToken,
      notification: { title, body },
      data: Object.fromEntries(
        Object.entries(data).map(([k, v]) => [k, String(v)])
      ),
      android: { priority: 'high' },
      apns:    { payload: { aps: { sound: 'default', badge: 1 } } }
    });

  } catch (err) {
    if (err.code === 'messaging/registration-token-not-registered') {
      // Token expired — clear it
      await db.collection('users').doc(userId).update({ fcmToken: '' });
    }
    console.error('FCM error:', err.message);
  }
};

const sendPushToMultiple = async (userIds, notification) => {
  await Promise.allSettled(
    userIds.map(id => sendPushNotification(id, notification))
  );
};

// ═══════════════════════════════════════════════════════
//  FIRESTORE SECURITY RULES  (paste in Firebase Console)
// ═══════════════════════════════════════════════════════
/*
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function isAuth() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return request.auth.uid == userId;
    }

    // Users: read approved users, write own doc
    match /users/{userId} {
      allow read:  if isAuth();
      allow write: if isOwner(userId);
    }

    // Chats: only participants can read/write
    match /chats/{chatId} {
      allow read, write: if isAuth() &&
        request.auth.uid in resource.data.participants;

      match /messages/{msgId} {
        allow read, write: if isAuth() &&
          request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participants;
      }
    }

    // Posts: any approved user can read; only owner can delete
    match /posts/{postId} {
      allow read:   if isAuth();
      allow create: if isAuth();
      allow update: if isAuth();   // for likes/comments
      allow delete: if isOwner(resource.data.userId);
    }
  }
}
*/

module.exports = {
  initFirebase,
  createOrUpdateUser,
  getUser,
  searchUsers,
  setOnlineStatus,
  sendMessage,
  getMessages,
  markMessagesSeen,
  createPost,
  getPosts,
  toggleLike,
  addComment,
  sendPushNotification,
  sendPushToMultiple,
  getChatId
};
