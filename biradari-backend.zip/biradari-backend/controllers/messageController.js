// controllers/messageController.js
const Chat    = require('../models/Chat');
const Message = require('../models/Message');
const User    = require('../models/User');

// ── Helper: find or create a chat between two users ──
const findOrCreateChat = async (userId1, userId2) => {
  const sorted = [userId1, userId2].sort();

  let chat = await Chat.findOne({
    participants: { $all: sorted, $size: 2 }
  });

  if (!chat) {
    chat = await Chat.create({ participants: sorted });
  }
  return chat;
};

// ── POST /api/messages/send ───────────────────────────
const sendMessage = async (req, res, next) => {
  try {
    const { receiverId, text, type = 'text' } = req.body;

    if (!receiverId) {
      return res.status(400).json({ success: false, message: 'receiverId required' });
    }
    if (!text && !req.file) {
      return res.status(400).json({ success: false, message: 'Message content required' });
    }

    const receiver = await User.findById(receiverId);
    if (!receiver) {
      return res.status(404).json({ success: false, message: 'Receiver not found' });
    }

    const chat = await findOrCreateChat(req.user._id, receiverId);

    const msgData = {
      chatId:     chat._id,
      senderId:   req.user._id,
      receiverId,
      type,
      text:       text || '',
      status:     'sent'
    };

    if (req.file) {
      msgData.mediaUrl  = `/uploads/messages/${req.file.filename}`;
      msgData.mediaSize = req.file.size;
      msgData.type      = req.body.type || 'image';
    }

    const message = await Message.create(msgData);

    // Update chat's lastMessage
    await Chat.findByIdAndUpdate(chat._id, {
      lastMessage:     message._id,
      lastMessageText: text || `[${msgData.type}]`,
      lastMessageTime: new Date(),
      $inc: { [`unreadCount.${receiverId}`]: 1 }
    });

    // Populate sender info
    await message.populate('senderId', 'name profilePic');

    // ── Real-time: emit to receiver's room ────────────
    const io = req.app.get('io');
    if (io) {
      io.to(`user_${receiverId}`).emit('newMessage', {
        message,
        chatId: chat._id
      });

      // Mark delivered if receiver is online
      if (receiver.online) {
        await Message.findByIdAndUpdate(message._id, {
          status: 'delivered',
          deliveredAt: new Date()
        });
        io.to(`user_${req.user._id}`).emit('messageDelivered', {
          messageId: message._id,
          chatId:    chat._id
        });
      }
    }

    res.status(201).json({ success: true, message });

  } catch (err) { next(err); }
};

// ── GET /api/messages/:userId  — chat history ────────
const getMessages = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { page = 1, limit = 30 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const chat = await findOrCreateChat(req.user._id, userId);

    const messages = await Message.find({
      chatId: chat._id,
      isDeleted: false
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('senderId', 'name profilePic')
      .populate('replyTo', 'text senderId type');

    // Mark unread messages as seen
    const unseenIds = messages
      .filter(m => m.receiverId.toString() === req.user._id.toString() && m.status !== 'seen')
      .map(m => m._id);

    if (unseenIds.length) {
      await Message.updateMany(
        { _id: { $in: unseenIds } },
        { status: 'seen', seenAt: new Date() }
      );

      // Reset unread count
      await Chat.findByIdAndUpdate(chat._id, {
        $set: { [`unreadCount.${req.user._id}`]: 0 }
      });

      // Notify sender messages were seen
      const io = req.app.get('io');
      if (io) {
        const otherUserId = userId;
        io.to(`user_${otherUserId}`).emit('messagesSeen', {
          chatId:    chat._id,
          seenBy:    req.user._id,
          messageIds: unseenIds
        });
      }
    }

    res.json({
      success: true,
      chatId:   chat._id,
      messages: messages.reverse(),  // oldest first
      page:     parseInt(page)
    });

  } catch (err) { next(err); }
};

// ── GET /api/messages/chats  — all conversations ─────
const getChats = async (req, res, next) => {
  try {
    const chats = await Chat.find({
      participants: req.user._id
    })
      .sort({ lastMessageTime: -1 })
      .populate('participants', 'name profilePic online lastSeen')
      .populate('lastMessage', 'text type status createdAt');

    // Add unread count for current user
    const result = chats.map(chat => {
      const other = chat.participants.find(
        p => p._id.toString() !== req.user._id.toString()
      );
      const unread = chat.unreadCount?.get(req.user._id.toString()) || 0;
      return { ...chat.toObject(), otherUser: other, unreadCount: unread };
    });

    res.json({ success: true, chats: result });

  } catch (err) { next(err); }
};

// ── DELETE /api/messages/:messageId ──────────────────
const deleteMessage = async (req, res, next) => {
  try {
    const msg = await Message.findOne({
      _id: req.params.messageId,
      senderId: req.user._id
    });

    if (!msg) return res.status(404).json({ success: false, message: 'Message not found' });

    msg.isDeleted = true;
    msg.text = '';
    msg.mediaUrl = '';
    await msg.save();

    const io = req.app.get('io');
    if (io) {
      io.to(`user_${msg.receiverId}`).emit('messageDeleted', {
        messageId: msg._id,
        chatId:    msg.chatId
      });
    }

    res.json({ success: true, message: 'Deleted' });

  } catch (err) { next(err); }
};

// ── PUT /api/messages/:messageId  — edit ─────────────
const editMessage = async (req, res, next) => {
  try {
    const { text } = req.body;
    const msg = await Message.findOne({
      _id:      req.params.messageId,
      senderId: req.user._id,
      isDeleted: false
    });

    if (!msg) return res.status(404).json({ success: false, message: 'Message not found' });

    msg.text     = text;
    msg.isEdited = true;
    msg.editedAt = new Date();
    await msg.save();

    const io = req.app.get('io');
    if (io) {
      io.to(`user_${msg.receiverId}`).emit('messageEdited', { message: msg });
    }

    res.json({ success: true, message: msg });

  } catch (err) { next(err); }
};

module.exports = { sendMessage, getMessages, getChats, deleteMessage, editMessage };
