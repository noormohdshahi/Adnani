// controllers/authController.js
const User            = require('../models/User');
const { generateToken } = require('../middleware/auth');

// ── Utility: generate 6-digit OTP ────────────────────
const makeOTP = () => String(Math.floor(100000 + Math.random() * 900000));

// ── POST /api/auth/send-otp ───────────────────────────
// Body: { phone }
const sendOTP = async (req, res, next) => {
  try {
    const { phone } = req.body;

    if (!phone || !/^\d{10}$/.test(phone)) {
      return res.status(400).json({ success: false, message: 'Valid 10-digit phone required' });
    }

    let user = await User.findOne({ phone });

    const otp = makeOTP();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min

    // ── New user — create pending ──────────────────────
    if (!user) {
      user = await User.create({
        phone,
        name: 'New Member',
        otp: { code: otp, expiresAt },
        status: 'pending'
      });
    } else {
      user.otp = { code: otp, expiresAt };
      await user.save();
    }

    // TODO: In production, send via SMS gateway (Twilio, MSG91, etc.)
    // For development — return OTP directly
    console.log(`📱 OTP for ${phone}: ${otp}`);

    res.json({
      success: true,
      message: 'OTP sent',
      ...(process.env.NODE_ENV === 'development' && { otp }) // dev only!
    });

  } catch (err) { next(err); }
};

// ── POST /api/auth/verify-otp ─────────────────────────
// Body: { phone, otp }
const verifyOTP = async (req, res, next) => {
  try {
    const { phone, otp } = req.body;

    if (!phone || !otp) {
      return res.status(400).json({ success: false, message: 'Phone and OTP required' });
    }

    const user = await User.findOne({ phone });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    if (!user.otp || !user.otp.code) {
      return res.status(400).json({ success: false, message: 'Request OTP first' });
    }

    if (user.otp.expiresAt < new Date()) {
      return res.status(400).json({ success: false, message: 'OTP expired' });
    }

    if (user.otp.code !== otp) {
      return res.status(401).json({ success: false, message: 'Wrong OTP' });
    }

    // Clear OTP
    user.otp = undefined;
    await user.save();

    const token = generateToken(user._id);

    // Determine what frontend should do next
    const isNewUser    = user.name === 'New Member' && !user.username;
    const needsProfile = isNewUser && user.role !== 'admin';

    res.json({
      success: true,
      token,
      needsProfileSetup: needsProfile,
      user: user.toPublicJSON()
    });

  } catch (err) { next(err); }
};

// ── POST /api/auth/setup-profile ─────────────────────
// Body: { name, username, city }  — first-time setup
const setupProfile = async (req, res, next) => {
  try {
    const { name, username, city, bio } = req.body;

    if (!name || name.trim().length < 2) {
      return res.status(400).json({ success: false, message: 'Name required' });
    }

    const user = await User.findById(req.user._id);

    // Check username uniqueness
    if (username) {
      const taken = await User.findOne({ username: username.toLowerCase(), _id: { $ne: user._id } });
      if (taken) {
        return res.status(400).json({ success: false, message: 'Username taken' });
      }
      user.username = username.toLowerCase();
    }

    user.name = name.trim();
    if (city) user.city = city;
    if (bio)  user.bio  = bio;

    await user.save();

    res.json({ success: true, user: user.toPublicJSON() });

  } catch (err) { next(err); }
};

// ── GET /api/auth/me ─────────────────────────────────
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select('-otp -fcmToken -socketId');
    res.json({ success: true, user });
  } catch (err) { next(err); }
};

module.exports = { sendOTP, verifyOTP, setupProfile, getMe };
