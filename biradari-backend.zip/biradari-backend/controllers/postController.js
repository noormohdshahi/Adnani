// controllers/postController.js
const Post = require('../models/Post');
const User = require('../models/User');

// ── POST /api/posts  — create post ───────────────────
const createPost = async (req, res, next) => {
  try {
    const { content, type = 'text' } = req.body;

    if (!content && !req.files?.length) {
      return res.status(400).json({ success: false, message: 'Post content required' });
    }

    const images = (req.files || []).map(f => `/uploads/posts/${f.filename}`);

    const post = await Post.create({
      userId:  req.user._id,
      content: content || '',
      images,
      type:    images.length ? 'image' : type
    });

    await post.populate('userId', 'name profilePic username');

    // ── Broadcast to all connected users ──────────────
    const io = req.app.get('io');
    if (io) {
      io.emit('newPost', { post });
    }

    res.status(201).json({ success: true, post });

  } catch (err) { next(err); }
};

// ── GET /api/posts  — feed ────────────────────────────
const getPosts = async (req, res, next) => {
  try {
    const { page = 1, limit = 15 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [posts, total] = await Promise.all([
      Post.find({ isDeleted: false })
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(parseInt(limit))
          .populate('userId', 'name profilePic username')
          .populate('comments.userId', 'name profilePic'),
      Post.countDocuments({ isDeleted: false })
    ]);

    // Add hasLiked flag for current user
    const result = posts.map(p => ({
      ...p.toJSON(),
      hasLiked: p.likes.some(id => id.toString() === req.user._id.toString()),
      likeCount: p.likes.length
    }));

    res.json({ success: true, posts: result, total, page: parseInt(page) });

  } catch (err) { next(err); }
};

// ── POST /api/posts/:id/like  — toggle like ───────────
const likePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: 'Post not found' });

    const userId   = req.user._id;
    const hasLiked = post.likes.some(id => id.toString() === userId.toString());

    if (hasLiked) {
      post.likes.pull(userId);
    } else {
      post.likes.addToSet(userId);
    }
    await post.save();

    const io = req.app.get('io');
    if (io) {
      io.emit('postLiked', {
        postId:    post._id,
        likeCount: post.likes.length,
        userId,
        liked: !hasLiked
      });
    }

    res.json({ success: true, liked: !hasLiked, likeCount: post.likes.length });

  } catch (err) { next(err); }
};

// ── POST /api/posts/:id/comment ───────────────────────
const addComment = async (req, res, next) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ success: false, message: 'Comment text required' });

    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: 'Post not found' });

    post.comments.push({ userId: req.user._id, text });
    await post.save();

    await post.populate('comments.userId', 'name profilePic');
    const newComment = post.comments[post.comments.length - 1];

    const io = req.app.get('io');
    if (io) io.emit('newComment', { postId: post._id, comment: newComment });

    res.status(201).json({ success: true, comment: newComment });

  } catch (err) { next(err); }
};

// ── DELETE /api/posts/:id/comment/:commentId ─────────
const deleteComment = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: 'Post not found' });

    const comment = post.comments.id(req.params.commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found' });

    // Only author or admin can delete
    if (comment.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorised' });
    }

    comment.deleteOne();
    await post.save();

    res.json({ success: true, message: 'Comment deleted' });

  } catch (err) { next(err); }
};

// ── DELETE /api/posts/:id ─────────────────────────────
const deletePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: 'Post not found' });

    if (post.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorised' });
    }

    post.isDeleted = true;
    await post.save();

    const io = req.app.get('io');
    if (io) io.emit('postDeleted', { postId: post._id });

    res.json({ success: true, message: 'Post deleted' });

  } catch (err) { next(err); }
};

module.exports = { createPost, getPosts, likePost, addComment, deleteComment, deletePost };
