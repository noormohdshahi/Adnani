// controllers/userController.js
const User = require('../models/User');

// ── GET /api/users  — search / list approved users ───
const getUsers = async (req, res, next) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const query = { status: 'approved', _id: { $ne: req.user._id } };

    if (search) {
      query.$or = [
        { name:     { $regex: search, $options: 'i' } },
        { username: { $regex: search, $options: 'i' } },
        { phone:    search }
      ];
    }

    const [users, total] = await Promise.all([
      User.find(query)
          .select('name username phone profilePic online lastSeen city bio')
          .sort({ name: 1 })
          .skip(skip)
          .limit(parseInt(limit)),
      User.countDocuments(query)
    ]);

    res.json({ success: true, users, total, page: parseInt(page) });

  } catch (err) { next(err); }
};

// ── GET /api/users/:id ────────────────────────────────
const getUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
      .select('name username profilePic online lastSeen city bio');

    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, user });

  } catch (err) { next(err); }
};

// ── GET /api/users/contacts ───────────────────────────
const getContacts = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('contacts', 'name username phone profilePic online lastSeen city');

    res.json({ success: true, contacts: user.contacts || [] });

  } catch (err) { next(err); }
};

// ── POST /api/users/contacts/:id  — add contact ──────
const addContact = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (id === req.user._id.toString()) {
      return res.status(400).json({ success: false, message: "Can't add yourself" });
    }

    const target = await User.findById(id);
    if (!target) return res.status(404).json({ success: false, message: 'User not found' });

    await User.findByIdAndUpdate(req.user._id, {
      $addToSet: { contacts: id }
    });

    res.json({ success: true, message: 'Contact added' });

  } catch (err) { next(err); }
};

// ── DELETE /api/users/contacts/:id ───────────────────
const removeContact = async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user._id, {
      $pull: { contacts: req.params.id }
    });
    res.json({ success: true, message: 'Contact removed' });
  } catch (err) { next(err); }
};

// ── PUT /api/users/profile ────────────────────────────
const updateProfile = async (req, res, next) => {
  try {
    const { name, username, bio, city, fcmToken } = req.body;
    const update = {};

    if (name)     update.name = name.trim();
    if (bio)      update.bio  = bio;
    if (city)     update.city = city;
    if (fcmToken) update.fcmToken = fcmToken;

    if (username) {
      const taken = await User.findOne({
        username: username.toLowerCase(),
        _id: { $ne: req.user._id }
      });
      if (taken) return res.status(400).json({ success: false, message: 'Username taken' });
      update.username = username.toLowerCase();
    }

    // Profile pic handled by multer
    if (req.file) {
      update.profilePic = `/uploads/profiles/${req.file.filename}`;
    }

    const user = await User.findByIdAndUpdate(req.user._id, update, {
      new: true, runValidators: true
    }).select('-otp -fcmToken -socketId');

    res.json({ success: true, user });

  } catch (err) { next(err); }
};

// ── GET /api/users/status  — online status ───────────
const getUserStatus = async (req, res, next) => {
  try {
    const { ids } = req.query;   // ?ids=id1,id2,id3
    const idArr = ids ? ids.split(',') : [];

    const users = await User.find({ _id: { $in: idArr } })
      .select('online lastSeen');

    const statusMap = {};
    users.forEach(u => {
      statusMap[u._id.toString()] = { online: u.online, lastSeen: u.lastSeen };
    });

    res.json({ success: true, status: statusMap });

  } catch (err) { next(err); }
};

// ── Admin: GET /api/users/pending ─────────────────────
const getPendingUsers = async (req, res, next) => {
  try {
    const users = await User.find({ status: 'pending' })
      .select('name phone city createdAt')
      .sort({ createdAt: -1 });
    res.json({ success: true, users });
  } catch (err) { next(err); }
};

// ── Admin: PUT /api/users/:id/approve ────────────────
const approveUser = async (req, res, next) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status: req.body.action === 'reject' ? 'blocked' : 'approved' },
      { new: true }
    );
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    // Emit real-time notification to the user
    const io = req.app.get('io');
    if (io && user.socketId) {
      io.to(user.socketId).emit('accountApproved', { status: user.status });
    }

    res.json({ success: true, user: user.toPublicJSON() });

  } catch (err) { next(err); }
};

module.exports = {
  getUsers, getUser, getContacts, addContact,
  removeContact, updateProfile, getUserStatus,
  getPendingUsers, approveUser
};
