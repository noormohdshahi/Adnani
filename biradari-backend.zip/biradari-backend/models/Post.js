// models/Post.js
const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  text:   { type: String, required: true, maxlength: 500 },
  createdAt: { type: Date, default: Date.now }
});

const PostSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  content: {
    type: String,
    maxlength: 1000,
    default: ''
  },
  images: [{
    type: String        // array of image URLs
  }],
  type: {
    type: String,
    enum: ['text', 'image', 'event', 'announcement'],
    default: 'text'
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  comments: [CommentSchema],
  visibility: {
    type: String,
    enum: ['all', 'members', 'admin'],
    default: 'all'
  },
  isDeleted: {
    type: Boolean,
    default: false,
    index: true
  }
}, {
  timestamps: true
});

// ── Indexes ──────────────────────────────────────────
PostSchema.index({ createdAt: -1 });
PostSchema.index({ userId: 1, createdAt: -1 });

// ── Virtual: like count ───────────────────────────────
PostSchema.virtual('likeCount').get(function () {
  return this.likes.length;
});

PostSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Post', PostSchema);
