// models/Chat.js
const mongoose = require('mongoose');

const ChatSchema = new mongoose.Schema({
  participants: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }],
  lastMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  },
  lastMessageText: String,     // cache for list preview
  lastMessageTime: Date,
  unreadCount: {               // unread per participant
    type: Map,
    of: Number,
    default: {}
  }
}, {
  timestamps: true
});

// Ensure only two participants, no duplicates
ChatSchema.index({ participants: 1 });
// Compound unique: sorted pair of participants
ChatSchema.index(
  { 'participants.0': 1, 'participants.1': 1 },
  { unique: false }
);

module.exports = mongoose.model('Chat', ChatSchema);
