// models/User.js
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [60, 'Name too long']
  },
  phone: {
    type: String,
    required: [true, 'Phone is required'],
    unique: true,
    trim: true,
    match: [/^\d{10}$/, 'Enter a valid 10-digit phone number']
  },
  username: {
    type: String,
    unique: true,
    sparse: true,     // allows multiple null
    lowercase: true,
    trim: true,
    minlength: 3,
    maxlength: 30
  },
  otp: {
    code: String,
    expiresAt: Date
  },
  profilePic: {
    type: String,
    default: ''
  },
  bio: {
    type: String,
    maxlength: 150,
    default: ''
  },
  city: {
    type: String,
    default: ''
  },
  role: {
    type: String,
    enum: ['member', 'admin'],
    default: 'member'
  },
  status: {
    type: String,
    enum: ['approved', 'pending', 'blocked'],
    default: 'pending'
  },
  online: {
    type: Boolean,
    default: false
  },
  lastSeen: {
    type: Date,
    default: Date.now
  },
  socketId: {
    type: String,
    default: ''
  },
  fcmToken: {         // for push notifications
    type: String,
    default: ''
  },
  contacts: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  blockedUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }]
}, {
  timestamps: true
});

// ── Indexes for fast queries ───────────────────────────
UserSchema.index({ phone: 1 });
UserSchema.index({ username: 1 });
UserSchema.index({ online: 1 });
UserSchema.index({ status: 1 });

// ── Remove sensitive fields from JSON output ──────────
UserSchema.methods.toPublicJSON = function () {
  const obj = this.toObject();
  delete obj.otp;
  delete obj.fcmToken;
  delete obj.socketId;
  delete obj.blockedUsers;
  return obj;
};

module.exports = mongoose.model('User', UserSchema);
