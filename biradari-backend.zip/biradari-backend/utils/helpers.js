// utils/helpers.js

// ── Pagination metadata ───────────────────────────────
const paginate = (page, limit, total) => ({
  currentPage: parseInt(page),
  totalPages:  Math.ceil(total / limit),
  totalItems:  total,
  hasNext:     parseInt(page) < Math.ceil(total / limit),
  hasPrev:     parseInt(page) > 1
});

// ── Format last seen ──────────────────────────────────
const formatLastSeen = (date) => {
  if (!date) return 'Unknown';
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  const hrs  = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (mins < 1)  return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  if (hrs  < 24) return `${hrs}h ago`;
  if (days < 7)  return `${days}d ago`;
  return new Date(date).toLocaleDateString('en-IN');
};

// ── Sanitise string input ─────────────────────────────
const sanitise = (str = '') =>
  str.replace(/[<>]/g, '').trim().slice(0, 2000);

// ── Generate chat key ─────────────────────────────────
const chatKey = (id1, id2) => [id1, id2].sort().join('_');

// ── API success wrapper ───────────────────────────────
const success = (res, data, statusCode = 200) =>
  res.status(statusCode).json({ success: true, ...data });

// ── API error wrapper ─────────────────────────────────
const fail = (res, message, statusCode = 400) =>
  res.status(statusCode).json({ success: false, message });

module.exports = { paginate, formatLastSeen, sanitise, chatKey, success, fail };
